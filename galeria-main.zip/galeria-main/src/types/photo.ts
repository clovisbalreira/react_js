export type Photo = {
    name: string;
    url: string;
}